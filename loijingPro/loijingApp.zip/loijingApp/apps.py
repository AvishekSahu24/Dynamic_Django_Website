from django.apps import AppConfig


class LoijingappConfig(AppConfig):
    name = 'loijingApp'
